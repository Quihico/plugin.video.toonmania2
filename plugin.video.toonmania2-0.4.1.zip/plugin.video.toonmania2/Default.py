# -*- coding: utf-8 -*-
from Lib.Client import main

main() # See bottom of client.py.